<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2021 &copy; Đại Học Sài Gòn</p>
        </div>
        <div class="float-end">
            <p>
                Được tạo 
                <span class="text-danger"><i class="bi bi-heart-fill icon-mid"></i></span>
                bởi <a href="#">Vip Pro Team</a>
            </p>
        </div>
    </div>
</footer>